/*Program Name: ConversionTest.java
 * Author: Julian Fuentes
 * Date Last Updated: 21 January 2024
 * Purpose: Convert feet to meters and vice versa.
 */

public class Conversions 
{
	public static double footToMeter(double foot) 
	{
		return 0.305 * foot;
	}
	
	public static double meterToFoot(double meter) 
	{
		return 3.279 * meter;
	}
}
