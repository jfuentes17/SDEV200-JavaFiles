/*Program Name: ConversionTest.java
 * Author: Julian Fuentes
 * Date Last Updated: 21 January 2024
 * Purpose: Convert feet to meters and vice versa.
 */

import java.util.*;

public class ConversionTest 
{
	public static void main(String[] args) 
	{
		//This should make the layout of the chart similart to the one in the book.
		System.out.println("Feet\tMeters\t\tMeters\tFeet");
		System.out.println("----\t------\t\t------\t-------");
		//I know that this doesn't look exactly like the chart in the book,
		//but I can't figure out how to make it look like the chart and
		//this is the best I could figure out as far as layout goes.
		
		for (double feet = 1.0; feet <= 10.0; feet++) 
		{
			//I've always been very anxious about using multiple classes in one project and not having everything
			//in the main class. I think it was because I always have had compiling issues in the past.
			double meters = Conversions.footToMeter(feet);
			double meter2 = 20 + 5 * (feet - 1);
			double feet2 = Conversions.meterToFoot(meter2);
			System.out.printf("%.1f\t%.3f\t\t%.1f\t%.3f%n", feet, meters, meter2, feet2);
			//I'll admit, I've always disliked the formatting line above and having to figure out
			//exactly how to write it with all the % and deciding how many decimal places and such.
			//It always takes me forever, along with a bunch of tries in order to get this right.
			//Also, the numbers in the last feet column didn't match up with the one in the book,
			//And I don't know why and can't figure it out.
		}
		
	}

}

