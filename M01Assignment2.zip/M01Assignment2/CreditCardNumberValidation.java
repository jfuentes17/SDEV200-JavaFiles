/*Program Name: CreditCardNumberValidation.java
 * Author: Julian Fuentes
 * Date Last Updated: 21 January 2024
 * Purpose: Validate if a credit card number is correct or not.
 */

import java.util.*;
import java.util.Scanner;

public class CreditCardNumberValidation 
{
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		//This creates a new scanner.
		System.out.print("Enter a credit card number as a long integer: ");
		long number = scan.nextLong();
		System.out.print(number + " is " + (isValid(number) ? "valid":"invalid"));
		scan.close();

	}
	
	public static boolean isValid(long number) 
	{
		boolean valid = 
				
				(getSize(number) >= 13 && getSize(number) <= 16)
				&& (prefixMatched(number,4) || prefixMatched(number,5)
				|| prefixMatched(number,37) || prefixMatched(number,6))
				&& ((sumOfDoubleEvenPlace(number) + sumOfOddPlace(number))%10 == 0);
		return valid;
	}
	//This will return true if the card number is valid.
	

	public static int sumOfDoubleEvenPlace(long number) 
	{
		int sum = 0;
		String number2 = number + "";
		for (int i = getSize(number)-2; i >= 0; i -= 2) 
		{
			sum += getDigit(Integer.parseInt(number2.charAt(i)+"") *2);
		}
		return sum;
	}
	//This should get the result from Step 2.
	
	public static int getDigit(int number) 
	{
		if (number < 9)
			return number;
		else
			return number/10 + number%10;
	}
	//This should return the number if it is a single digit, otherwise,
	//it will return the sum of the two digits.
	
	public static int sumOfOddPlace(long number) 
	{
		int sum = 0;
		String number2 = number + "";
		for (int i = getSize(number)-1; i >= 0; i -=2) 
		{
			sum += Integer.parseInt(number2.charAt(i)+"");
		}
		return sum;
	}
	//This should return the sum of the odd-place digits in number.
	
	public static boolean prefixMatched(long number, int d) 
	{
		return getPrefix(number, getSize(d))==d;
	}
	//This should return true if the number d is a prefix for number.
	
	public static int getSize(long d) 
	{
		String number2 = d + "";
		return number2.length();
	}
	//This should return the number of digits in d.
	
	public static long getPrefix(long number, int k) 
	{
		if (getSize(number) > k) 
		{
			String number2 = number + "";
			return Long.parseLong(number2.substring(0,k));
		}
		return number;
	}
	//This should return the first k number of digits from number.
	//If the number of digits in number is less than k, return number.
	

}
